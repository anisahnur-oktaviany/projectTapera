<?php
  $host ="localhost"; //host server
  $user ="root"; //user login phpMyAdmin
  $pass =""; //pass login phpMyAdmin
  $db ="rkat"; //nama database
  $koneksi = mysqli_connect($host, $user, $pass, $db) or die ("Koneksi gagal");

// mengaktifkan session pada php
session_start();

// menangkap data yang dikirim dari form login
if (isset($_POST['login'])) {

$email = $_POST['mail'];
$password = $_POST['pass'];
 
// menyeleksi data user dengan username dan password yang sesuai
$login = mysqli_query($koneksi,"SELECT * FROM direktorat WHERE username='$email' and password='$password'");
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($login);
 
// cek apakah username dan password di temukan pada database
if($cek > 0){
 
	$data = mysqli_fetch_assoc($login);

	// cek jika user login sebagai admin
	if($data['role']=="Admin"){
 
// buat session login dan username
$_SESSION['username'] = $email;
$_SESSION['role'] = "Admin";
// alihkan ke halaman dashboard admin
header('location:admin');

// cek jika user login sebagai pengurus
}else if($data['role']=="User"){
// buat session login dan username
$_SESSION['username'] = $email;
$_SESSION['role'] = "User";
// alihkan ke halaman dashboard pengurus
header('location:user');

}else{
// alihkan ke halaman login kembali
echo 'Akun tidak ditemukan';
header("location:login.php");
}	
}
}
?>